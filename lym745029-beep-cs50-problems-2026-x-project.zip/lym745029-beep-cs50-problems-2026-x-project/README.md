# Oil & Gas Management System
#### Video Demo:  <YOUR YOUTUBE URL HERE>
#### Description:
Oil & Gas Management System is a web-based application developed as my final project for CS50’s Introduction to Computer Science.

The purpose of the application is to provide a simple system for managing oil and gas wells and recording their production data. In the oil and gas industry, companies need to track many wells and their daily production. Using spreadsheets can lead to errors and duplicate data. This application solves that problem by providing a centralized database where all well information and production records are stored safely.

The application allows users to create and manage a list of wells. For each well, the user can enter the well name, location, type, and drilling date. The wells are displayed on the main dashboard so that the user can easily see the wells currently stored in the system.

The application also allows users to record production data for individual wells. Production records contain the well, production date, oil production in barrels, and gas production in MCF. The system prevents duplicate production records for the same well and date to ensure accurate reporting.

The main dashboard provides an overview of the stored wells and calculates the total oil and gas production recorded in the database. This gives the user a quick summary of the production information without having to calculate the totals manually. The reports page shows all production entries in a table sorted by date.

The project uses Python and Flask to provide the web application and handle requests from the user. SQLite is used as the database system because it is lightweight and does not require a separate database server. The application creates two main database tables: wells and production.

The wells table stores information about each oil or gas well, including its name, location, type, and drilling date. Each well has a unique ID. The production table stores production records and connects each record to a well using the well ID. It also stores the production date, oil barrels, and gas MCF.

#### Files:
- `app.py`: Main Flask application. Handles routing, database connection, and all business logic. Creates tables if they don't exist. Contains all routes for dashboard, add well, add production, and reports.
- `oilgas.db`: SQLite database file that stores wells and production data. Created automatically when the app runs for the first time.
- `templates/dashboard.html`: Main page showing navigation, total oil and gas production, and list of all wells.
- `templates/add_well.html`: Form to add a new well with fields for name, location, type, and drill date.
- `templates/add_production.html`: Form to add production data. User selects a well from dropdown and enters date, oil, and gas values.
- `templates/reports.html`: Table view of all production records showing date, well name, oil, and gas.

#### Database Design:
The application uses two main tables with a relationship between them:

1.  **wells**: `id` PRIMARY KEY, `well_name` UNIQUE, `location`, `well_type`, `drill_date`
2.  **production**: `id` PRIMARY KEY, `well_id` FOREIGN KEY, `prod_date`, `oil_barrels`, `gas_mcf`
    Foreign key: `well_id` references `wells.id` ON DELETE CASCADE
        Unique constraint: `(well_id, prod_date)` to prevent duplicate entries for same well on same day

        Using foreign keys ensures that every production record is linked to a valid well. The unique constraints prevent data duplication.

        #### Design Choices:
        - **Flask**: Chosen for its simplicity and because it was covered in CS50. Perfect for a small web app. It allows quick development without complex configuration.
        - **SQLite**: Lightweight, no server setup needed, stores data in a single file. Ideal for a student project and easy to submit.
        - **Bootstrap 5**: Used for a clean, responsive UI without writing custom CSS. Makes the app look professional on desktop and mobile.
        - **Template Separation**: HTML separated from Python logic for better organization and maintenance. Follows MVC pattern.
        - **Unique Constraints**: Added in the database to ensure data integrity and prevent human error.
        - **Parameterized Queries**: Used to prevent SQL injection attacks and keep the database secure.

        #### Technologies Used:
        Python 3, Flask, SQLite3, HTML5, CSS3, Bootstrap 5, Jinja2 Templating

        #### How to Run:
        1.  Make sure you have Python 3 and Flask installed: `pip install flask`
        2.  Navigate to the project directory in your terminal
        3.  Run the application: `flask run`
        4.  Open your browser and go to: `http://127.0.0.1:5000`
        5.  The database will be created automatically on first run

        #### Project Features:
        - Add oil and gas wells with validation
        - Store well location and drilling date
        - Record daily oil production in barrels
        - Record daily gas production in MCF
        - View total oil production on dashboard
        - View total gas production on dashboard
        - View detailed production reports in table format
        - Store information persistently using SQLite
        - Prevent duplicate well names
        - Prevent duplicate production records for the same well and date
        - Responsive design works on mobile and desktop

        #### Challenges and Solutions:
        During development I faced several challenges. The first challenge was preventing duplicate data. I solved this by adding UNIQUE constraints in the SQLite database for well_name and for the combination of well_id + prod_date. This ensures data integrity and avoids confusion in reports.

        The second challenge was displaying totals on the dashboard efficiently. I used SQL SUM() functions to calculate total oil and gas production directly in the database query instead of calculating in Python. This makes the application faster, especially as the database grows larger.

        The third challenge was making the interface user-friendly for non-technical users. I chose Bootstrap 5 because it provides responsive design out of the box. This means the application works well on both desktop and mobile without writing custom CSS. I also added clear navigation buttons and success messages after form submissions.

        The fourth challenge was handling form errors. I added server-side validation to check that required fields are not empty and that production numbers are not negative before inserting into the database.

        #### Future Improvements:
        If I had more time I would add user authentication so that each user can only see and manage their own wells. I would also add data visualization using Chart.js to show production trends over time with line graphs and bar charts. Another important improvement would be the ability to export reports to CSV or PDF format for sharing with management. I would add search and filter functionality to quickly find specific wells or production records by date range. Finally, I would deploy the application online using a service like PythonAnywhere so that multiple users can access it.

        #### What I Learned:
        This project helped me understand how to build a full-stack web application from scratch. I learned how to connect Flask to SQLite, how to design a relational database, and how to use Jinja2 templates to display dynamic data. I also learned how to handle forms with POST requests and how to redirect users after successful submissions. This project showed me how important it is to plan the database structure before writing code. I gained experience with debugging and testing a real application. Most importantly, I learned how to break a big problem into smaller parts and solve each part step by step.

        #### Usage Example:
        A company can use this system to track 10 wells in different locations across Sudan. Each day the field engineer logs into the system and enters the oil and gas production for each well. At the end of the month the manager can go to the Reports page to see all data and to the Dashboard to see total production for the month. This saves significant time compared to using Excel spreadsheets and reduces the chance of calculation errors. The system can grow to handle hundreds of wells and years of production data.

        #### Acknowledgements:
        This project was created as the final project for CS50’s Introduction to Computer Science.
        AI tools were used for debugging, code suggestions, and documentation assistance. All code was reviewed and understood before submission.


https://youtu.be/pdkTGAI8aoc?si=ovFW19q4NAhECJWb


